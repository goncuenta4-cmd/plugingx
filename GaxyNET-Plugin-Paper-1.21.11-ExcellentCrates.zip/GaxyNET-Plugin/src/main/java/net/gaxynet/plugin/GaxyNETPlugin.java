package net.gaxynet.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class GaxyNETPlugin extends JavaPlugin {
    private NamespacedKey keyId;
    private org.bukkit.configuration.file.FileConfiguration data;
    private java.io.File dataFile;

    @Override public void onEnable() {
        saveDefaultConfig();
        keyId = new NamespacedKey(this, "gaxy_key");
        dataFile = new java.io.File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            try { getDataFolder().mkdirs(); dataFile.createNewFile(); }
            catch (Exception e) { getLogger().severe("No se pudo crear data.yml: " + e.getMessage()); }
        }
        data = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(dataFile);
        getLogger().info("GaxyNET activado para Paper 1.21.11. Recompensa diaria: " + getConfig().getInt("daily-reward", 300));
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) { help(sender); return true; }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "daily" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("Este comando es solo para jugadores."); return true; }
                String path = "players." + p.getUniqueId() + ".lastDaily";
                long now = System.currentTimeMillis();
                long last = data.getLong(path, 0L);
                long cooldown = Math.max(1, getConfig().getInt("daily-cooldown-hours", 24)) * 3_600_000L;
                if (now - last < cooldown) {
                    long left = cooldown - (now - last);
                    long hours = left / 3_600_000L; long minutes = (left % 3_600_000L) / 60_000L;
                    p.sendMessage(color("&d[Gaxy NET] &fYa reclamaste tu recompensa. Vuelve en &e" + hours + "h " + minutes + "m&f."));
                    return true;
                }
                int reward = Math.max(0, getConfig().getInt("daily-reward", 300));
                data.set(path, now); saveData();
                // Moneda virtual guardada en el archivo del plugin; no es dinero de Vault.
                String balancePath = "players." + p.getUniqueId() + ".coins";
                int balance = data.getInt(balancePath, 0) + reward;
                data.set(balancePath, balance); saveData();
                p.sendMessage(color("&d✦ &dGaxy NET &8» &f¡Recompensa diaria! &e+" + reward + " monedas"));
                p.sendMessage(color("&7Saldo Gaxy NET: &e" + balance + " monedas"));
                return true;
            }
            case "balance" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("Este comando es solo para jugadores."); return true; }
                sender.sendMessage(color("&d[Gaxy NET] &fTus monedas: &e" + data.getInt("players." + p.getUniqueId() + ".coins", 0)));
                return true;
            }
            case "keys" -> {
                sender.sendMessage(color("&d✦ &fLlaves disponibles de &dGaxy NET&f:"));
                for (String id : getConfig().getConfigurationSection("keys").getKeys(false)) sender.sendMessage(color("&8 • &f" + id));
                sender.sendMessage(color("&7Admin: /gaxynet givekey <jugador> <llave> [cantidad]"));
                return true;
            }
            case "givekey" -> {
                if (!sender.hasPermission("gaxynet.admin")) { sender.sendMessage(color("&cNo tienes permiso.")); return true; }
                if (args.length < 3) { sender.sendMessage("Uso: /gaxynet givekey <jugador> <llave> [cantidad]"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage("Jugador no conectado. Escribe su nick exacto y asegúrate de que esté en línea."); return true; }
                String id = args[2].toLowerCase(Locale.ROOT);
                if (!getConfig().isConfigurationSection("keys." + id)) { sender.sendMessage("Llave desconocida. Usa /gaxynet keys"); return true; }
                int amount = 1;
                if (args.length >= 4) try { amount = Integer.parseInt(args[3]); } catch (NumberFormatException ignored) { amount = 1; }
                amount = Math.max(1, Math.min(64, amount));
                if (getConfig().getBoolean("excellentcrates.enabled", true)) {
                    if (Bukkit.getPluginManager().getPlugin("ExcellentCrates") == null) {
                        sender.sendMessage(color("&cExcellentCrates no está instalado o no se cargó. No se entregó ninguna llave."));
                        return true;
                    }
                    String crateKey = getConfig().getString("excellentcrates.keys." + id, id);
                    String template = getConfig().getString("excellentcrates.command", "crates key give %player% %key% %amount%");
                    String commandLine = template.replace("%player%", target.getName())
                            .replace("%key%", crateKey == null ? id : crateKey)
                            .replace("%amount%", Integer.toString(amount));
                    boolean dispatched = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), commandLine);
                    if (dispatched) {
                        target.sendMessage(color("&d[Gaxy NET] &fSe procesó la entrega de &e" + amount + "x &fllave &d" + id + "&f."));
                        sender.sendMessage("Orden de ExcellentCrates enviada: " + id + " x" + amount + " a " + target.getName() + ". Verifica el ID de la llave en config.yml.");
                    } else {
                        sender.sendMessage(color("&cExcellentCrates rechazó la orden. Comprueba la sintaxis del comando y el ID de la llave."));
                    }
                    return true;
                }
                ItemStack item = createKey(id, amount);
                var leftovers = target.getInventory().addItem(item);
                leftovers.values().forEach(stack -> target.getWorld().dropItemNaturally(target.getLocation(), stack));
                target.sendMessage(color("&d[Gaxy NET] &fRecibiste &e" + amount + "x &fLlave personalizada &d" + id + "&f."));
                sender.sendMessage("Llave personalizada " + id + " entregada a " + target.getName() + " x" + amount + ".");
                return true;
            }
            case "diamonds" -> {
                if (!sender.hasPermission("gaxynet.admin")) { sender.sendMessage(color("&cNo tienes permiso.")); return true; }
                if (args.length < 2) { sender.sendMessage("Uso: /gaxynet diamonds <jugador> [cantidad]"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage("Ese jugador debe estar conectado."); return true; }
                int amount = 16;
                if (args.length >= 3) try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) { }
                amount = Math.max(1, Math.min(2304, amount));
                ItemStack diamonds = new ItemStack(Material.DIAMOND, Math.min(amount, 64));
                int remaining = amount - diamonds.getAmount();
                target.getInventory().addItem(diamonds);
                while (remaining > 0) { int stack = Math.min(64, remaining); target.getInventory().addItem(new ItemStack(Material.DIAMOND, stack)); remaining -= stack; }
                target.sendMessage(color("&d[Gaxy NET] &fRecibiste &b" + amount + " diamantes&f."));
                sender.sendMessage("Entregados " + amount + " diamantes a " + target.getName() + ".");
                return true;
            }
            case "reload" -> {
                if (!sender.hasPermission("gaxynet.admin")) { sender.sendMessage(color("&cNo tienes permiso.")); return true; }
                reloadConfig(); sender.sendMessage(color("&aConfiguración de Gaxy NET recargada.")); return true;
            }
            default -> { help(sender); return true; }
        }
    }

    private ItemStack createKey(String id, int amount) {
        String base = "keys." + id + ".";
        Material material = Material.matchMaterial(getConfig().getString(base + "material", "TRIPWIRE_HOOK"));
        if (material == null || !material.isItem()) material = Material.TRIPWIRE_HOOK;
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color(getConfig().getString(base + "display-name", "&dLlave " + id)));
        List<String> lore = getConfig().getStringList(base + "lore");
        if (!lore.isEmpty()) { List<String> colored = new ArrayList<>(); lore.forEach(line -> colored.add(color(line))); meta.setLore(colored); }
        meta.getPersistentDataContainer().set(keyId, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return item;
    }
    private void saveData() { try { data.save(dataFile); } catch (Exception e) { getLogger().severe("No se pudo guardar data.yml: " + e.getMessage()); } }
    private void help(CommandSender s) {
        s.sendMessage(color("&d✦ &lGaxy NET &7— comandos"));
        s.sendMessage(color("&f/gaxynet daily &7- reclama 300 monedas cada 24 h"));
        s.sendMessage(color("&f/gaxynet balance &7- consulta tus monedas"));
        s.sendMessage(color("&f/gaxynet keys &7- lista las llaves"));
        if (s.hasPermission("gaxynet.admin")) { s.sendMessage(color("&f/gaxynet givekey <jugador> <llave> [cantidad]")); s.sendMessage(color("&f/gaxynet diamonds <jugador> [cantidad]")); s.sendMessage(color("&f/gaxynet reload")); }
    }
    private String color(String text) { return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text); }
}
